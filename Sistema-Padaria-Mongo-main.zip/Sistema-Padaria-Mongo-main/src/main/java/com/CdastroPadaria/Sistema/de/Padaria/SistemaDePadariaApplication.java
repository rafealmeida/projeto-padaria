package com.CdastroPadaria.Sistema.de.Padaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDePadariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDePadariaApplication.class, args);
	}

}
