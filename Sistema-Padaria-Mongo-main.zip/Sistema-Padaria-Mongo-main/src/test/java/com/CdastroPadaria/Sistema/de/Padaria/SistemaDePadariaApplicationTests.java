package com.CdastroPadaria.Sistema.de.Padaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDePadariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
